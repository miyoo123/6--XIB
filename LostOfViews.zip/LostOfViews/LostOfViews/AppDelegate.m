//
//  AppDelegate.m
//  LostOfViews
//
//  Created by miyoo on 16/1/23.
//  Copyright (c) 2016年 miyoo. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    
    
    
    
    
    
    
    
    return YES;
}


@end
